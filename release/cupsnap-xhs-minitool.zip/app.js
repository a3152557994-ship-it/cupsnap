// Xiaohongshu 2026-11-25 Container Bridge (ES2017 + Chrome 61 safe)
function supportsFlexGap() {
  if (!document.body) return false;
  var flex = document.createElement("div");
  flex.style.position = "absolute";
  flex.style.visibility = "hidden";
  flex.style.display = "flex";
  flex.style.flexDirection = "column";
  flex.style.rowGap = "1px";
  flex.appendChild(document.createElement("div"));
  flex.appendChild(document.createElement("div"));
  document.body.appendChild(flex);
  var supported = flex.scrollHeight === 1;
  flex.parentNode.removeChild(flex);
  return supported;
}

function readBuildVersion(launchOptions) {
  var env = launchOptions && launchOptions.miniToolEnv;
  var val = env && env.buildVersion;
  if (typeof val !== "number" && typeof val !== "string") return null;
  if (!/^[1-9]\d{6,}$/.test(String(val))) return null;
  var ver = Number(val);
  return Number.isSafeInteger(ver) ? ver : null;
}

async function getBuildVersion() {
  var xhs = window.xhs;
  var syncVer = readBuildVersion(xhs && xhs.launchOptions);
  if (syncVer !== null) return syncVer;
  var mt = xhs && xhs.miniTool;
  if (!mt || typeof mt.getLaunchOptions !== "function") return null;
  try {
    var opts = await mt.getLaunchOptions();
    return readBuildVersion(opts);
  } catch (e) {
    return null;
  }
}

function getClientVersion(buildVersion) {
  return (Number.isSafeInteger(buildVersion) && buildVersion > 0)
    ? Math.floor(buildVersion / 1000)
    : null;
}

async function applyWindowAvoidance() {
  var mt = window.xhs && window.xhs.miniTool;
  var snap = window.xhs && window.xhs.launchOptions && window.xhs.launchOptions.miniToolEnv && window.xhs.launchOptions.miniToolEnv.windowInfo;
  function applyInfo(info) {
    if (!info || !info.safeArea) return;
    var mb = info.menuButtons || {};
    var cap = mb.capsule;
    function vis(r) { return r && r.width > 0 && r.height > 0; }
    var rects = vis(cap) ? [cap] : [mb.back, mb.me, mb.share].filter(vis);
    var top = info.safeArea.top || 0;
    for (var i = 0; i < rects.length; i++) {
      if (rects[i].bottom > top) top = rects[i].bottom;
    }
    document.documentElement.style.setProperty("--content-top", (top + 8) + "px");
  }
  if (snap) applyInfo(snap);
  var bv = await getBuildVersion();
  var cv = getClientVersion(bv);
  if (cv !== null && cv >= 9490 && mt && typeof mt.getWindowInfo === "function") {
    try {
      var liveInfo = await mt.getWindowInfo();
      applyInfo(liveInfo);
    } catch (e) {}
  }
}

async function xhsSaveData(key, obj) {
  var raw;
  try { raw = JSON.stringify(obj); } catch (e) { return false; }
  if (typeof raw !== "string") return false;
  var bv = await getBuildVersion();
  var cv = getClientVersion(bv);
  var mt = window.xhs && window.xhs.miniTool;
  if (cv === null) return false;
  if (cv < 9460) {
    try { localStorage.setItem(key, raw); return true; } catch (e) { return false; }
  }
  if (!mt || typeof mt.setStorage !== "function") return false;
  try {
    var res = await mt.setStorage({ key: key, data: raw });
    return !!(res && res.errMsg === "setStorage:ok");
  } catch (e) {
    return false;
  }
}

async function xhsLoadData(key) {
  var bv = await getBuildVersion();
  var cv = getClientVersion(bv);
  var mt = window.xhs && window.xhs.miniTool;
  if (cv === null) return null;
  if (cv < 9460) {
    try {
      var s = localStorage.getItem(key);
      return (!s) ? null : JSON.parse(s);
    } catch (e) { return null; }
  }
  if (!mt || typeof mt.getStorage !== "function") return null;
  try {
    var res = await mt.getStorage({ key: key });
    var d = res && res.data;
    if (d === null || d === "" || typeof d !== "string") return null;
    return JSON.parse(d);
  } catch (e) {
    return undefined;
  }
}

async function xhsTapHaptic() {
  var bv = await getBuildVersion();
  var cv = getClientVersion(bv);
  var mt = window.xhs && window.xhs.miniTool;
  if (cv !== null && cv >= 9500 && mt && typeof mt.vibrateShort === "function") {
    try { await mt.vibrateShort({ type: "light" }); } catch (e) {}
  }
}

async function xhsCanvasToFileOrData(canvas) {
  var dataUrl = canvas.toDataURL("image/png");
  var mt = window.xhs && window.xhs.miniTool;
  if (mt && typeof mt.writeTempFile === "function") {
    try {
      var tmp = await mt.writeTempFile({ data: dataUrl });
      if (tmp && tmp.filePath) return tmp.filePath;
    } catch (e) {}
  }
  return dataUrl;
}

async function xhsSaveCanvasToAlbum(canvas, onToast) {
  var mt = window.xhs && window.xhs.miniTool;
  if (!mt || typeof mt.saveImageToPhotosAlbum !== "function") {
    onToast("请在小红书 App 内打开以一键保存高清图至相册");
    return;
  }
  try {
    var fp = await xhsCanvasToFileOrData(canvas);
    await mt.saveImageToPhotosAlbum({ filePath: fp });
    await xhsTapHaptic();
    onToast("已保存高清 3:4 海报到系统相册 ✨");
  } catch (e) {
    onToast("保存未完成：" + ((e && e.errMsg) ? e.errMsg : "请授权相册权限后重试"));
  }
}

async function xhsPostCanvasNote(canvas, title, content, onToast) {
  var mt = window.xhs && window.xhs.miniTool;
  if (!mt || typeof mt.postNote !== "function") {
    onToast("请在小红书 App 内点击即可一键带海报发笔记");
    return;
  }
  try {
    var fp = await xhsCanvasToFileOrData(canvas);
    await mt.postNote({
      title: title.slice(0, 20),
      content: content.slice(0, 900),
      pageType: "photo_publish",
      mediaInfo: { image_resources: [{ url: fp }] }
    });
  } catch (e) {
    onToast("拉起发布页未完成，可先点「存相册」再发笔记");
  }
}

async function xhsSetupShareBtn(btnEl, onToast) {
  if (!btnEl) return;
  var bv = await getBuildVersion();
  var cv = getClientVersion(bv);
  var mt = window.xhs && window.xhs.miniTool;
  if (cv !== null && cv >= 9530 && mt && typeof mt.share === "function") {
    btnEl.style.display = "inline-flex";
    btnEl.addEventListener("click", async function () {
      try {
        await mt.share({ type: "card" });
      } catch (e) {
        onToast("当前半屏或模拟器暂不支持分享面板");
      }
    });
  } else {
    btnEl.style.display = "none";
  }
}

(function () {
  var PRESETS = [
    { emoji: "🧋", brand: "霸王茶姬", drink: "伯牙绝弦", price: 20, tilt: -5 },
    { emoji: "🥥", brand: "瑞幸咖啡", drink: "生椰拿铁", price: 9.9, tilt: 4 },
    { emoji: "🌸", brand: "爷爷不泡茶", drink: "荔枝冰酿", price: 17, tilt: -3 },
    { emoji: "🍵", brand: "茶百道", drink: "抹茶云顶", price: 19, tilt: -4 },
    { emoji: "🍓", brand: "古茗", drink: "芝士莓莓", price: 18, tilt: 3 },
    { emoji: "🍇", brand: "喜茶", drink: "多肉葡萄", price: 19, tilt: -2 },
    { emoji: "🍋", brand: "柠季", drink: "手打柠檬茶", price: 16, tilt: 4 }
  ];

  var STORAGE_KEY = "cupsnap_minitool_v1";
  var now = new Date();
  var year = now.getFullYear();
  var month = now.getMonth();
  var selectedDay = now.getDate();
  var currentPhotoData = null;
  var currentEmoji = "🌸";

  function defaultSeed() {
    return {
      "1": { brand: "霸王茶姬", drink: "伯牙绝弦", price: 20, sugar: "30%", emoji: "🧋", tilt: -5 },
      "3": { brand: "瑞幸咖啡", drink: "生椰拿铁", price: 9.9, sugar: "0%", emoji: "🥥", tilt: 4 },
      "6": { brand: "爷爷不泡茶", drink: "荔枝冰酿", price: 17, sugar: "30%", emoji: "🌸", tilt: -3 },
      "10": { brand: "茶百道", drink: "抹茶云顶", price: 19, sugar: "30%", emoji: "🍵", tilt: -4 },
      "14": { brand: "古茗", drink: "芝士莓莓", price: 18, sugar: "50%", emoji: "🍓", tilt: 3 },
      "18": { brand: "喜茶", drink: "多肉葡萄", price: 19, sugar: "50%", emoji: "🍇", tilt: -2 }
    };
  }

  var records = defaultSeed();

  function showToast(msg) {
    var box = document.getElementById("toastBox");
    if (!box) return;
    box.textContent = msg;
    box.style.display = "block";
    setTimeout(function () { box.style.display = "none"; }, 3200);
  }

  function updatePreview() {
    var prev = document.getElementById("stickerPreview");
    prev.innerHTML = "";
    if (currentPhotoData) {
      var img = document.createElement("img");
      img.src = currentPhotoData;
      img.alt = "cup";
      prev.appendChild(img);
    } else {
      prev.textContent = currentEmoji;
    }
  }

  function renderPresets() {
    var box = document.getElementById("emojiPresets");
    box.innerHTML = "";
    for (var i = 0; i < PRESETS.length; i++) {
      (function (p) {
        var b = document.createElement("button");
        b.type = "button";
        b.className = "pill-btn" + (currentEmoji === p.emoji && !currentPhotoData ? " active" : "");
        b.textContent = p.emoji + " " + p.brand;
        b.addEventListener("click", function () {
          currentPhotoData = null;
          currentEmoji = p.emoji;
          document.getElementById("brandInput").value = p.brand;
          document.getElementById("drinkInput").value = p.drink;
          document.getElementById("priceInput").value = String(p.price);
          updatePreview();
          renderPresets();
        });
        box.appendChild(b);
      })(PRESETS[i]);
    }
  }

  function roundRect(ctx, x, y, w, h, r, fill) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
    ctx.fillStyle = fill;
    ctx.fill();
  }

  function drawPoster(list, totalCups, totalSpend, topBrand) {
    var cv = document.getElementById("posterCanvas");
    var ctx = cv.getContext("2d");
    ctx.fillStyle = "#FAF2E6";
    ctx.fillRect(0, 0, 900, 1200);

    ctx.fillStyle = "#8B7260";
    ctx.font = "700 24px -apple-system, sans-serif";
    var mStr = String(month + 1).padStart(2, "0");
    ctx.fillText(year + "." + mStr + " · 贴一杯手账日历", 60, 88);

    ctx.fillStyle = "#6E3F24";
    ctx.font = "900 54px -apple-system, PingFang SC, sans-serif";
    ctx.fillText((month + 1) + "月续命饮品手账", 60, 154);

    ctx.textAlign = "right";
    ctx.font = "900 72px -apple-system, sans-serif";
    ctx.fillText(String(totalCups), 840, 140);
    ctx.font = "700 22px -apple-system, PingFang SC, sans-serif";
    ctx.fillStyle = "#8B7260";
    ctx.fillText("本月贴纸杯", 840, 174);
    ctx.textAlign = "left";

    roundRect(ctx, 60, 206, 780, 118, 28, "#EFE0CC");
    ctx.fillStyle = "#6E3F24";
    ctx.font = "800 34px -apple-system, PingFang SC, sans-serif";
    var badgeTitle = totalCups >= 5 ? ("🏆 " + topBrand + " 荣誉股东") : "🏆 城市饮品收集家";
    ctx.fillText(badgeTitle, 94, 260);
    ctx.font = "600 23px -apple-system, PingFang SC, sans-serif";
    ctx.fillStyle = "#80573E";
    ctx.fillText("本月共贴 " + totalCups + " 杯 · 续命投入 ¥" + totalSpend.toFixed(0) + " · 把快乐贴成彩色日历", 94, 300);

    roundRect(ctx, 60, 352, 780, 580, 34, "#FFFDF9");
    var shown = list.slice(0, 12);
    for (var idx = 0; idx < shown.length; idx++) {
      var item = shown[idx];
      var col = idx % 4;
      var row = Math.floor(idx / 4);
      var x = 96 + col * 182;
      var y = 388 + row * 176;
      roundRect(ctx, x, y, 154, 130, 24, "#FAF5EC");
      ctx.textAlign = "center";
      ctx.font = "64px Apple Color Emoji, sans-serif";
      ctx.fillText(item.emoji || "🧋", x + 77, y + 86);
      ctx.fillStyle = "#6E3F24";
      ctx.font = "700 20px -apple-system, PingFang SC, sans-serif";
      ctx.fillText(String(item.drink || "").slice(0, 6), x + 77, y + 152);
      ctx.textAlign = "left";
    }

    var boxes = [
      ["总花费", "¥" + totalSpend.toFixed(0)],
      ["最爱品牌", String(topBrand).slice(0, 6)],
      ["月均杯价", totalCups ? ("¥" + (totalSpend / totalCups).toFixed(1)) : "¥0"]
    ];
    for (var b = 0; b < boxes.length; b++) {
      var bx = 60 + b * 268;
      roundRect(ctx, bx, 964, 244, 112, 24, "#EFE0CC");
      ctx.textAlign = "center";
      ctx.fillStyle = "#8B7260";
      ctx.font = "700 22px -apple-system, PingFang SC, sans-serif";
      ctx.fillText(boxes[b][0], bx + 122, 1006);
      ctx.fillStyle = "#6E3F24";
      ctx.font = "900 34px -apple-system, PingFang SC, sans-serif";
      ctx.fillText(boxes[b][1], bx + 122, 1054);
      ctx.textAlign = "left";
    }

    ctx.fillStyle = "#8B7260";
    ctx.font = "600 22px -apple-system, PingFang SC, sans-serif";
    ctx.fillText("贴一杯 CupSnap · 奶茶咖啡贴纸手账日历", 60, 1142);
  }

  function updateStatsAndPoster() {
    var keys = Object.keys(records).sort(function (a, b) { return Number(a) - Number(b); });
    var list = [];
    var totalSpend = 0;
    var counts = {};
    for (var i = 0; i < keys.length; i++) {
      var rec = records[keys[i]];
      if (!rec) continue;
      list.push(rec);
      totalSpend += Number(rec.price) || 0;
      counts[rec.brand] = (counts[rec.brand] || 0) + 1;
    }
    var topBrand = "—";
    var topCnt = 0;
    var brands = Object.keys(counts);
    for (var j = 0; j < brands.length; j++) {
      if (counts[brands[j]] > topCnt) {
        topCnt = counts[brands[j]];
        topBrand = brands[j];
      }
    }
    document.getElementById("statCups").textContent = list.length + " 杯";
    document.getElementById("statSpend").textContent = "¥" + totalSpend.toFixed(0);
    document.getElementById("statTop").textContent = topBrand;
    drawPoster(list, list.length, totalSpend, topBrand);
    return { cups: list.length, spend: totalSpend, topBrand: topBrand };
  }

  function renderCalendar() {
    var grid = document.getElementById("calGrid");
    grid.innerHTML = "";
    var firstDow = (new Date(year, month, 1).getDay() + 6) % 7;
    var daysInMonth = new Date(year, month + 1, 0).getDate();
    for (var i = 0; i < firstDow; i++) {
      grid.appendChild(document.createElement("div"));
    }
    for (var d = 1; d <= daysInMonth; d++) {
      (function (dayNum) {
        var cell = document.createElement("div");
        cell.className = "day-cell" + (dayNum === selectedDay ? " active" : "");
        var numSpan = document.createElement("span");
        numSpan.className = "day-num";
        numSpan.textContent = String(dayNum);
        cell.appendChild(numSpan);

        var rec = records[String(dayNum)];
        if (rec) {
          var chip = document.createElement("div");
          chip.className = "sticker-chip";
          chip.style.transform = "rotate(" + (rec.tilt || -3) + "deg)";
          if (rec.photo) {
            var im = document.createElement("img");
            im.src = rec.photo;
            im.alt = "cup";
            chip.appendChild(im);
          } else {
            chip.textContent = rec.emoji || "🧋";
          }
          cell.appendChild(chip);
        }
        cell.addEventListener("click", function () {
          selectedDay = dayNum;
          document.getElementById("selectedDayLabel").textContent = (month + 1) + "月" + dayNum + "日";
          var r = records[String(dayNum)];
          if (r) {
            document.getElementById("brandInput").value = r.brand || "";
            document.getElementById("drinkInput").value = r.drink || "";
            document.getElementById("priceInput").value = String(r.price || 18);
            document.getElementById("sugarSelect").value = r.sugar || "30%";
            currentPhotoData = r.photo || null;
            currentEmoji = r.emoji || "🧋";
            updatePreview();
          }
          renderCalendar();
        });
        grid.appendChild(cell);
      })(d);
    }
    updateStatsAndPoster();
  }

  async function init() {
    if (supportsFlexGap()) {
      document.documentElement.classList.add("supports-flex-gap");
    }
    applyWindowAvoidance();
    document.getElementById("selectedDayLabel").textContent = (month + 1) + "月" + selectedDay + "日";

    var saved = await xhsLoadData(STORAGE_KEY);
    if (saved && typeof saved === "object") {
      records = saved;
    }

    document.getElementById("photoInput").addEventListener("change", function (e) {
      var file = e.target.files && e.target.files[0];
      if (!file) return;
      var reader = new FileReader();
      reader.onload = function (ev) {
        var img = new Image();
        img.onload = function () {
          var c = document.createElement("canvas");
          c.width = 180;
          c.height = 180;
          var cx = c.getContext("2d");
          var s = Math.min(img.width, img.height);
          cx.drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, 180, 180);
          currentPhotoData = c.toDataURL("image/jpeg", 0.78);
          updatePreview();
          renderPresets();
        };
        img.src = ev.target.result;
      };
      reader.readAsDataURL(file);
    });

    document.getElementById("stickBtn").addEventListener("click", async function () {
      records[String(selectedDay)] = {
        brand: document.getElementById("brandInput").value.trim() || "自选茶饮",
        drink: document.getElementById("drinkInput").value.trim() || "今日续命水",
        price: Number(document.getElementById("priceInput").value) || 18,
        sugar: document.getElementById("sugarSelect").value,
        emoji: currentEmoji,
        photo: currentPhotoData,
        tilt: (selectedDay % 2 === 0 ? 4 : -4)
      };
      await xhsTapHaptic();
      await xhsSaveData(STORAGE_KEY, records);
      renderCalendar();
      showToast("已贴上 " + (month + 1) + "月" + selectedDay + "日 的饮品贴纸 ✨");
    });

    document.getElementById("clearDayBtn").addEventListener("click", async function () {
      delete records[String(selectedDay)];
      await xhsSaveData(STORAGE_KEY, records);
      renderCalendar();
    });

    document.getElementById("saveAlbumBtn").addEventListener("click", function () {
      var cv = document.getElementById("posterCanvas");
      xhsSaveCanvasToAlbum(cv, showToast);
    });

    document.getElementById("postNoteBtn").addEventListener("click", function () {
      var st = updateStatsAndPoster();
      var cv = document.getElementById("posterCanvas");
      var title = (month + 1) + "月奶茶手账：" + st.cups + "杯¥" + st.spend.toFixed(0);
      var content = "用「贴一杯」拼出了我的" + (month + 1) + "月续命饮品贴纸日历！本月最爱：" + st.topBrand + " 🧋✨ #奶茶手账 #咖啡打卡 #每月饮品总结 #贴一杯";
      xhsPostCanvasNote(cv, title, content, showToast);
    });

    xhsSetupShareBtn(document.getElementById("shareCardBtn"), showToast);
    renderPresets();
    renderCalendar();
  }

  init();
})();
